
//добавление нового пользователя
const users = [];

const addUser = ({ id, username, room }) => {
  // очиста данных
  username = username.trim().toLowerCase();
  room = room.trim().toLowerCase();

  // Проверка 
  if (!username || !room) {
    return {
      error: "Нужно указать имя пользователя!"
    };
  }

  // проврка на сущ пользователя
  const existingUser = users.find(user => {
    return user.room === room && user.username === username;
  });

  // Проверка 
  if (existingUser) {
    return {
      error: "Имя пользователя используется!"
    };
  }

  // возвращение информации о пользователях(добавление их в список)
  const user = { id, username, room };
  users.push(user);
  return { user };
};
//удаляет пользователя из массива(Если пользователь найден, функция возвращает удаленного пользователя.)
const removeUser = id => {
  const index = users.findIndex(user => user.id === id);

  if (index !== -1) {
    return users.splice(index, 1)[0];
  }
};
//нахождение пользователя в массиве
const getUser = id => {
  return users.find(user => user.id === id);
};
//нахождение всех пользователей в конкретной комнате и возвращает их.
const getUsersInRoom = room => {
  room = room.trim().toLowerCase();
  return users.filter(user => user.room === room);
};
//экспорт функций
module.exports = {
  addUser,
  removeUser,
  getUser,
  getUsersInRoom
};
