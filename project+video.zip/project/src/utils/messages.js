

//модули двух функций:
//generateMessage: генерирует объект сообщения с данными о пользователе, текстом сообщения и временем создания
//generateLocationMessage: генерирует объект сообщения с данными о пользователе, URL местоположения и временем создания.

const generateMessage = (username, text) => {
  return {
    username,
    text,
    createdAt: new Date().getTime()
  };
};

const generateLocationMessage = (username, url) => {
  return {
    username,
    url,
    createdAt: new Date().getTime()
  };
};

module.exports = {
  generateMessage,
  generateLocationMessage
};
