// Импортируем необходимые модули
const path = require("path");
const http = require("http");
const express = require("express");
const socketio = require("socket.io");
const Filter = require("bad-words");
const { generateMessage, generateLocationMessage } = require("./utils/messages");
const { addUser, removeUser, getUser, getUsersInRoom } = require("./utils/users");
// Создаем приложение Express и сервер HTTP
const app = express();
const server = http.createServer(app);
const io = socketio(server);
// Загружаем переменные окружения из файла .env
require("dotenv").config();
// Устанавливаем порт для сервера
const port = process.env.PORT || 3000;
const publicDirectoryPath = path.join(__dirname, "../public");

app.use(express.static(publicDirectoryPath));
// Устанавливаем событии Socket.IO

io.on("connection", socket => {
  console.log("новый пользователь законектился");
// Обрабатываем событие "join", которое происходит при подключении пользователя к комнате 
  socket.on("join", (options, callback) => {
    const { error, user } = addUser({ id: socket.id, ...options });
    if (error) {
      return callback(error);
    } else {
      socket.join(user.room);
      // Отправляем приветстве
      socket.emit("message", generateMessage("Администратор", "привет! это ваш чат"));
      socket.broadcast.to(user.room).emit("message", generateMessage("Администратор", `${user.username} присоеденился к чату!`));
      // Отправляем данные комнаты пользователю и другим пользователям в комнате
      io.to(user.room).emit("roomData", {
        room: user.room,
        users: getUsersInRoom(user.room)
      });

      callback();
    }
  });
  //событие "sendMessage" при отправки сообщения чата (проверка нецензурной лексике(не доработано))
  socket.on("sendMessage", (message, callback) => {
    const user = getUser(socket.id);
    const filter = new Filter();

    if (filter.isProfane(message)) {
      return callback;
    } else {
      io.to(user.room).emit("message", generateMessage(user.username, message));
      callback();
    }
  });
  // отправка геолокации 
  socket.on("sendLocation", (coords, callback) => {
    const user = getUser(socket.id);
    io.to(user.room).emit("locationMessage", generateLocationMessage(user.username, `https://www.google.com/maps?q=${coords.latitude},${coords.longitude}`));
    callback();
  });
  //происходит при отключении пользователя от чата
  socket.on("disconnect", () => {
    const user = removeUser(socket.id); //удаляем пользователя

    if (user) {
      io.to(user.room).emit("message", generateMessage("Администратор", `${user.username} вышел из чата!`));
      io.to(user.room).emit("roomData", {
        room: user.room,
        users: getUsersInRoom(user.room)
      });
    }
  });
});
// Запускаем сервер
server.listen(port, () => {
  console.log(`сервер запущен на порту: ${port}`);
});
